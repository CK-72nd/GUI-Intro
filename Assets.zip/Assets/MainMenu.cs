﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MainMenu : MonoBehaviour
{
    #region Variables
    [Header("Bools")]
    public bool gameScene, showOptions, showPause;

    [Header("Keys")]
    public KeyCode forward;
    public KeyCode backward;
    public KeyCode left;
    public KeyCode right;
    public KeyCode jump;
    public KeyCode crouch;
    public KeyCode sprint;
    public KeyCode interact;
    // This remembers the key code of a key
    // We are trying to change
    public KeyCode holdingKey;
    [Header("GUI Text")]
    public Text forwardText;
    public Text backwardsText;
    public Text leftText;
    public Text rightText;
    public Text jumpText;
    public Text crouchText;
    public Text sprintText;
    public Text interactText;

    [Header("References")]
    public GameObject menu, options, pause;
    public Slider volumeSlider, brightnessSlider;
    public AudioSource music;
    public Light dirLight;
    #endregion

    void Start()
    {
        Time.timeScale = 1;
        if (PlayerPrefs.HasKey("Volume"))
        {
            Load();
        }
        if (volumeSlider != null && music != null)
        {

            volumeSlider.value = music.volume;
        }
        brightnessSlider.value = dirLight.intensity;

        #region SetUp Keys
        // Set out keys to the preset keys we may have saved, else set the keys to default
        forward = (KeyCode)System.Enum.Parse(typeof(KeyCode), PlayerPrefs.GetString("Forward", "W"));
        backward = (KeyCode)System.Enum.Parse(typeof(KeyCode), PlayerPrefs.GetString("Backward", "S"));
        left = (KeyCode)System.Enum.Parse(typeof(KeyCode), PlayerPrefs.GetString("Left", "A"));
        right = (KeyCode)System.Enum.Parse(typeof(KeyCode), PlayerPrefs.GetString("Right", "D"));
        jump = (KeyCode)System.Enum.Parse(typeof(KeyCode), PlayerPrefs.GetString("Jump", "Space"));
        crouch = (KeyCode)System.Enum.Parse(typeof(KeyCode), PlayerPrefs.GetString("Crouch", "LeftControl"));
        sprint = (KeyCode)System.Enum.Parse(typeof(KeyCode), PlayerPrefs.GetString("Sprint", "LeftShift"));
        interact = (KeyCode)System.Enum.Parse(typeof(KeyCode), PlayerPrefs.GetString("Interact", "E"));

        forwardText.text = forward.ToString();
        backwardsText.text = backward.ToString();
        leftText.text = left.ToString();
        rightText.text = right.ToString();
        jumpText.text = jump.ToString();
        crouchText.text = crouch.ToString();
        sprintText.text = sprint.ToString();
        interactText.text = interact.ToString();
        #endregion
    }


    void Update()
    {

        if (volumeSlider != null && music != null)
        {
            if (music.volume != volumeSlider.value)
            {
                music.volume = volumeSlider.value;
            }

        }
        if (brightnessSlider != null && dirLight != null)
        {
            if (brightnessSlider.value != dirLight.intensity)
            {
                dirLight.intensity = brightnessSlider.value;
            }
        }

        if (showPause)
        {
            music.volume = volumeSlider.GetComponent<Slider>().value;

        }

        if (gameScene)
        {
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                TogglePause();
            }
        }

    }

    public void Play()
    {
        SceneManager.LoadScene(1);
    }
    public void Exit()
    {
        Application.Quit();
        Debug.Log("Quit");
    }

    public void ShowOptions()
    {
        ToggleOptions();
    }
    public bool ToggleOptions()
    {
        if (showOptions)
        {
            showOptions = false;
            menu.SetActive(true);
            options.SetActive(false);
            return false;
        }
        else
        {
            showOptions = true;
            menu.SetActive(false);
            options.SetActive(true);
            return true;
        }

    }

    public void ShowPause()
    {
        TogglePause();
    }

    public bool TogglePause()
    {
        if (!showPause)
        {
            showPause = true;
            pause.SetActive(true);
            Time.timeScale = 0;
            return true;
        }
        else
        {
            showPause = false;
            pause.SetActive(false);
            Time.timeScale = 1;
            return false;
        }
    }

    public void Save()
    {
        PlayerPrefs.SetFloat("Volume", music.volume);
        PlayerPrefs.SetFloat("Brightness", dirLight.intensity);

        PlayerPrefs.SetString("Forward", forward.ToString());
        PlayerPrefs.SetString("Backward", backward.ToString());
        PlayerPrefs.SetString("Left", left.ToString());
        PlayerPrefs.SetString("Right", right.ToString());
        PlayerPrefs.SetString("Jump", jump.ToString());
        PlayerPrefs.SetString("sprint", sprint.ToString());
        PlayerPrefs.SetString("Crouch", crouch.ToString());
        PlayerPrefs.SetString("Interact", interact.ToString());
    }

    public void Load()
    {
        music.volume = PlayerPrefs.GetFloat("Volume");
        dirLight.intensity = PlayerPrefs.GetFloat("Brightness");

    

       
    }

    public void Default()
    {
        volumeSlider.value = 1;
        brightnessSlider.value = 1;
        PlayerPrefs.SetFloat("Volume", 1);
        PlayerPrefs.SetFloat("Brightness", 1);
    }

    
    #region Controls
    public void Forward()
    {
        // if none of the keys are blank
        // then we can edit this key
        if (!(backward == KeyCode.None || left == KeyCode.None || right == KeyCode.None || jump == KeyCode.None || crouch == KeyCode.None || sprint == KeyCode.None || interact == KeyCode.None))
        {
            // set our holding key to the key of this action
            holdingKey = forward;
            // set this button to non allowing only this to be editable
            forward = KeyCode.None;
            // set this text to none
            forwardText.text = forward.ToString();
        }
    }
    public void Backward()
    {
        if (!(forward == KeyCode.None || left == KeyCode.None || right == KeyCode.None || jump == KeyCode.None || crouch == KeyCode.None || sprint == KeyCode.None || interact == KeyCode.None))
        {    // set our holding key to the key of this action
            holdingKey = backward;
            // set this button to non allowing only this to be editable
            backward = KeyCode.None;
            // set this text to none
            backwardsText.text = backward.ToString();
        }
    }
    public void Left()
    {
        if (!(backward == KeyCode.None || forward == KeyCode.None || right == KeyCode.None || jump == KeyCode.None || crouch == KeyCode.None || sprint == KeyCode.None || interact == KeyCode.None))
        {   // set our holding key to the key of this action
            holdingKey = left;
            // set this button to non allowing only this to be editable
            left = KeyCode.None;
            // set this text to none
            leftText.text = left.ToString();
        }
    }
    public void Right()
    {
        if (!(backward == KeyCode.None || left == KeyCode.None || forward == KeyCode.None || jump == KeyCode.None || crouch == KeyCode.None || sprint == KeyCode.None || interact == KeyCode.None))
        {   // set our holding key to the key of this action
            holdingKey = right;
            // set this button to non allowing only this to be editable
            right = KeyCode.None;
            // set this text to none
            rightText.text = right.ToString();
        }
    }
    public void Jump()
    {
        if (!(backward == KeyCode.None || left == KeyCode.None || right == KeyCode.None || forward == KeyCode.None || crouch == KeyCode.None || sprint == KeyCode.None || interact == KeyCode.None))
        {   // set our holding key to the key of this action
            holdingKey = jump;
            // set this button to non allowing only this to be editable
            jump = KeyCode.None;
            // set this text to none
            jumpText.text = jump.ToString();
        }
    }
    public void Crouch()
    {
        if (!(backward == KeyCode.None || left == KeyCode.None || right == KeyCode.None || jump == KeyCode.None || forward == KeyCode.None || sprint == KeyCode.None || interact == KeyCode.None))
        {   // set our holding key to the key of this action
            holdingKey = crouch;
            // set this button to non allowing only this to be editable
            crouch = KeyCode.None;
            // set this text to none
            crouchText.text = crouch.ToString();
        }
    }
    public void Sprint()
    {
        if (!(backward == KeyCode.None || left == KeyCode.None || right == KeyCode.None || jump == KeyCode.None || crouch == KeyCode.None || forward == KeyCode.None || interact == KeyCode.None))
        {   // set our holding key to the key of this action
            holdingKey = sprint;
            // set this button to non allowing only this to be editable
            sprint = KeyCode.None;
            // set this text to none
            sprintText.text = sprint.ToString();
        }
    }
    public void Interact()
    {
        if (!(backward == KeyCode.None || left == KeyCode.None || right == KeyCode.None || jump == KeyCode.None || crouch == KeyCode.None || sprint == KeyCode.None || forward == KeyCode.None))
        {   // set our holding key to the key of this action
            holdingKey = interact;
            // set this button to non allowing only this to be editable
            interact = KeyCode.None;
            // set this text to none
            interactText.text = interact.ToString();
        }
    }
    #endregion

    #region Key Press Event
    void OnGUI()
    {
        Event e = Event.current;
        // if forward is set to none
        if (forward == KeyCode.None)
        {
            // if an event is triggered by a key press
            if (e.isKey)
            {
                Debug.Log("Key Pressed: " + e.keyCode);
                // if that key is not the same as any other key
                if (!(e.keyCode == backward || e.keyCode == left || e.keyCode == right || e.keyCode == jump || e.keyCode == sprint || e.keyCode == crouch || e.keyCode == interact))
                {
                    // set forward to the event key that was pressed
                    forward = e.keyCode;
                    // set the holding key to none
                    holdingKey = KeyCode.None;
                    // set the GUI to the new key
                    forwardText.text = forward.ToString();
                }
                else
                {
                    //set the forward key back to the previous key
                    forward = holdingKey;
                    // set the holding key to none
                    holdingKey = KeyCode.None;
                    // set the GUI to the previous key
                    forwardText.text = forward.ToString();
                }
            }
        }
            if (backward == KeyCode.None)
            {
                // if an event is triggered by a key press
                if (e.isKey)
                {
                    Debug.Log("Key Pressed: " + e.keyCode);
                    // if that key is not the same as any other key
                    if (!(e.keyCode == forward || e.keyCode == left || e.keyCode == right || e.keyCode == jump || e.keyCode == sprint || e.keyCode == crouch || e.keyCode == interact))
                    {
                        // set forward to the event key that was pressed
                        backward = e.keyCode;
                        // set the holding key to none
                        holdingKey = KeyCode.None;
                        // set the GUI to the new key
                        backwardsText.text = backward.ToString();
                    }
                    else
                    {
                        //set the forward key back to the previous key
                        backward = holdingKey;
                        // set the holding key to none
                        holdingKey = KeyCode.None;
                        // set the GUI to the previous key
                        backwardsText.text = backward.ToString();
                    }
                }
            }
        if (left == KeyCode.None)
        {
            // if an event is triggered by a key press
            if (e.isKey)
            {
                Debug.Log("Key Pressed: " + e.keyCode);
                // if that key is not the same as any other key
                if (!(e.keyCode == backward || e.keyCode == forward || e.keyCode == right || e.keyCode == jump || e.keyCode == sprint || e.keyCode == crouch || e.keyCode == interact))
                {
                    // set forward to the event key that was pressed
                    left = e.keyCode;
                    // set the holding key to none
                    holdingKey = KeyCode.None;
                    // set the GUI to the new key
                    leftText.text = left.ToString();
                }
                else
                {
                    //set the forward key back to the previous key
                    left = holdingKey;
                    // set the holding key to none
                    holdingKey = KeyCode.None;
                    // set the GUI to the previous key
                    leftText.text = left.ToString();
                }
            }
        }
        if (right == KeyCode.None)
        {
            // if an event is triggered by a key press
            if (e.isKey)
            {
                Debug.Log("Key Pressed: " + e.keyCode);
                // if that key is not the same as any other key
                if (!(e.keyCode == backward || e.keyCode == left || e.keyCode == forward || e.keyCode == jump || e.keyCode == sprint || e.keyCode == crouch || e.keyCode == interact))
                {
                    // set forward to the event key that was pressed
                    right = e.keyCode;
                    // set the holding key to none
                    holdingKey = KeyCode.None;
                    // set the GUI to the new key
                    rightText.text = right.ToString();
                }
                else
                {
                    //set the forward key back to the previous key
                    right = holdingKey;
                    // set the holding key to none
                    holdingKey = KeyCode.None;
                    // set the GUI to the previous key
                    rightText.text = right.ToString();
                }
            }
        }
        if (jump == KeyCode.None)
        {
            // if an event is triggered by a key press
            if (e.isKey)
            {
                Debug.Log("Key Pressed: " + e.keyCode);
                // if that key is not the same as any other key
                if (!(e.keyCode == backward || e.keyCode == left || e.keyCode == right || e.keyCode == forward || e.keyCode == sprint || e.keyCode == crouch || e.keyCode == interact))
                {
                    // set forward to the event key that was pressed
                    jump = e.keyCode;
                    // set the holding key to none
                    holdingKey = KeyCode.None;
                    // set the GUI to the new key
                    jumpText.text = jump.ToString();
                }
                else
                {
                    //set the forward key back to the previous key
                    jump = holdingKey;
                    // set the holding key to none
                    holdingKey = KeyCode.None;
                    // set the GUI to the previous key
                    jumpText.text = jump.ToString();
                }
            }
        }
        if (sprint == KeyCode.None)
        {
            // if an event is triggered by a key press
            if (e.isKey)
            {
                Debug.Log("Key Pressed: " + e.keyCode);
                // if that key is not the same as any other key
                if (!(e.keyCode == backward || e.keyCode == left || e.keyCode == right || e.keyCode == jump || e.keyCode == forward || e.keyCode == crouch || e.keyCode == interact))
                {
                    // set forward to the event key that was pressed
                    sprint = e.keyCode;
                    // set the holding key to none
                    holdingKey = KeyCode.None;
                    // set the GUI to the new key
                    sprintText.text = sprint.ToString();
                }
                else
                {
                    //set the forward key back to the previous key
                    sprint = holdingKey;
                    // set the holding key to none
                    holdingKey = KeyCode.None;
                    // set the GUI to the previous key
                    sprintText.text = sprint.ToString();
                }
            }
        }
        if (crouch == KeyCode.None)
        {
            // if an event is triggered by a key press
            if (e.isKey)
            {
                Debug.Log("Key Pressed: " + e.keyCode);
                // if that key is not the same as any other key
                if (!(e.keyCode == backward || e.keyCode == left || e.keyCode == right || e.keyCode == jump || e.keyCode == sprint || e.keyCode == forward || e.keyCode == interact))
                {
                    // set forward to the event key that was pressed
                    crouch = e.keyCode;
                    // set the holding key to none
                    holdingKey = KeyCode.None;
                    // set the GUI to the new key
                    crouchText.text = crouch.ToString();
                }
                else
                {
                    //set the forward key back to the previous key
                    crouch = holdingKey;
                    // set the holding key to none
                    holdingKey = KeyCode.None;
                    // set the GUI to the previous key
                    crouchText.text = crouch.ToString();
                }
            }
        }
        if (interact == KeyCode.None)
        {
            // if an event is triggered by a key press
            if (e.isKey)
            {
                Debug.Log("Key Pressed: " + e.keyCode);
                // if that key is not the same as any other key
                if (!(e.keyCode == backward || e.keyCode == left || e.keyCode == right || e.keyCode == jump || e.keyCode == sprint || e.keyCode == crouch || e.keyCode == forward))
                {
                    // set forward to the event key that was pressed
                    interact = e.keyCode;
                    // set the holding key to none
                    holdingKey = KeyCode.None;
                    // set the GUI to the new key
                    interactText.text = interact.ToString();
                }
                else
                {
                    //set the forward key back to the previous key
                    interact = holdingKey;
                    // set the holding key to none
                    holdingKey = KeyCode.None;
                    // set the GUI to the previous key
                    interactText.text = interact.ToString();
                }
            }
        }
        }
    }
    #endregion

 /*
 RESOLUTIONS
 3640 * 2160
 1920 * 1080
 1280 * 720
 2560 * 1440
 1680 * 960
 1152 * 648
 1600 * 900
 1024 * 576

    Screen.SetResolution(x, y, fullscreen(bool));
    */
   






